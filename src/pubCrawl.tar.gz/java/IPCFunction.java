public abstract class IPCFunction extends PCObject
{
    public abstract PCObject call(PCObject... args);
}