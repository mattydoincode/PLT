#!/bin/bash

cd java
java -jar DistributeServer.jar $1
